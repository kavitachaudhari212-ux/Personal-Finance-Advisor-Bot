import os, datetime as dt, requests
from collections import defaultdict
from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import (LoginManager, UserMixin, login_user, logout_user,
                         login_required, current_user)
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv

load_dotenv()
BASE = os.path.abspath(os.path.dirname(__file__))
app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY") or "dev-secret-change-me"
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL") or "sqlite:///" + os.path.join(BASE, "finance.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = "login"
CUR = "₹"
DEFAULT_CATS = ["Rent/Housing", "Food", "Transport", "Utilities", "Entertainment", "Health", "Shopping", "Education", "Other"]

# ---------- Models ----------
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    occupation = db.Column(db.String(80), default="")
    goals_text = db.Column(db.String(300), default="")

class Category(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    name = db.Column(db.String(50), nullable=False)

class Income(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    source = db.Column(db.String(80), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    date = db.Column(db.Date, nullable=False)

class Expense(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    category = db.Column(db.String(50), nullable=False)
    description = db.Column(db.String(120), default="")
    amount = db.Column(db.Float, nullable=False)
    date = db.Column(db.Date, nullable=False)

class Budget(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    category = db.Column(db.String(50), nullable=False)
    limit = db.Column(db.Float, nullable=False)

class Goal(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    name = db.Column(db.String(80), nullable=False)
    target = db.Column(db.Float, nullable=False)
    saved = db.Column(db.Float, default=0)

class AIReport(db.Model):  # stores budget plans, analyses and monthly reports
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    kind = db.Column(db.String(20), nullable=False)
    month = db.Column(db.String(7), nullable=False)
    content = db.Column(db.Text, nullable=False)
    created = db.Column(db.DateTime, default=dt.datetime.utcnow)

@login_manager.user_loader
def load_user(uid):
    return db.session.get(User, int(uid))

# ---------- Helpers ----------
def parse_amount(v):
    try:
        a = float(v)
        return a if a > 0 else None
    except (TypeError, ValueError):
        return None

def parse_date(v):
    try:
        return dt.datetime.strptime(v, "%Y-%m-%d").date()
    except (TypeError, ValueError):
        return dt.date.today()

def cur_month():
    m = request.args.get("month") or dt.date.today().strftime("%Y-%m")
    try:
        dt.datetime.strptime(m, "%Y-%m")
    except ValueError:
        m = dt.date.today().strftime("%Y-%m")
    return m

def month_range(m):
    s = dt.datetime.strptime(m, "%Y-%m").date()
    e = dt.date(s.year + (s.month == 12), s.month % 12 + 1, 1)
    return s, e

def summary(uid, m):
    s, e = month_range(m)
    inc = Income.query.filter(Income.user_id == uid, Income.date >= s, Income.date < e).all()
    exp = Expense.query.filter(Expense.user_id == uid, Expense.date >= s, Expense.date < e).all()
    by_cat = defaultdict(float)
    for x in exp:
        by_cat[x.category] += x.amount
    budgets = {b.category: b.limit for b in Budget.query.filter_by(user_id=uid)}
    ti, te = sum(i.amount for i in inc), sum(x.amount for x in exp)
    over = [(c, by_cat[c], l) for c, l in budgets.items() if by_cat.get(c, 0) > l]
    return dict(income=ti, expenses=te, savings=ti - te,
                rate=round((ti - te) / ti * 100, 1) if ti else 0,
                by_cat=dict(by_cat), budgets=budgets, over=over)

def summary_text(u, m, s):
    goals = "; ".join(f"{g.name} {g.saved:.0f}/{g.target:.0f}" for g in Goal.query.filter_by(user_id=u.id)) or "none"
    return (f"User: {u.name}, occupation: {u.occupation or 'n/a'}, stated goals: {u.goals_text or 'n/a'}\n"
            f"Month: {m}\nIncome: {CUR}{s['income']:.0f}\nExpenses: {CUR}{s['expenses']:.0f}\n"
            f"Savings rate: {s['rate']}%\nSpending by category: {s['by_cat']}\n"
            f"Budget limits: {s['budgets']}\nSavings goals: {goals}")

# ---------- AI (Gemini via REST, with rule-based fallback) ----------
PROMPTS = {
    "budget": "Create a personalized monthly budget (category-wise amounts in rupees, needs/wants/savings split, emergency-fund target of 3-6 months of expenses).",
    "analysis": "Analyze spending: detect overspending, compare with typical healthy ratios, give cost-optimization tips and a financial health score out of 100.",
    "monthly": "Write a concise monthly financial summary report: highlights, problems, savings progress, and 5 actionable recommendations for next month.",
}

def call_gemini(prompt):
    key = os.getenv("GEMINI_API_KEY")
    if not key:
        return None
    model = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    try:
        r = requests.post(url, params={"key": key}, timeout=60,
                          json={"contents": [{"parts": [{"text": prompt}]}]})
        r.raise_for_status()
        return r.json()["candidates"][0]["content"]["parts"][0]["text"]
    except Exception as ex:
        print("Gemini error:", ex)
        return None

def rule_based(kind, s):
    inc, exp = s["income"], s["expenses"]
    if inc <= 0:
        return "Add your income for this month first so advice can be generated."
    L = []
    if kind == "budget":
        L += [f"Suggested budget on income {CUR}{inc:.0f} (50/30/20 rule):",
              f"- Needs (housing, food, transport, utilities): {CUR}{inc*.5:.0f}",
              f"- Wants (entertainment, shopping): {CUR}{inc*.3:.0f}",
              f"- Savings/investments: {CUR}{inc*.2:.0f}",
              f"- Emergency fund target (6 months of expenses): {CUR}{max(exp, inc*.5)*6:.0f}"]
    else:
        L.append(f"Income {CUR}{inc:.0f}, expenses {CUR}{exp:.0f}, savings rate {s['rate']}%.")
        score = max(0, min(100, int(50 + s["rate"] * 2.5 - len(s["over"]) * 8)))
        L.append(f"Financial health score: {score}/100.")
        for c, spent, lim in s["over"]:
            L.append(f"- Overspending in {c}: {CUR}{spent:.0f} vs limit {CUR}{lim:.0f}. Cut about {CUR}{spent-lim:.0f}.")
        if s["by_cat"]:
            top = max(s["by_cat"], key=s["by_cat"].get)
            L.append(f"- Largest category is {top} ({CUR}{s['by_cat'][top]:.0f}, {s['by_cat'][top]/max(exp,1)*100:.0f}% of spending); review it first.")
        if s["rate"] < 20:
            L.append("- Savings rate is below the recommended 20%. Automate a transfer to savings on payday.")
        L.append(f"- Emergency fund: aim for {CUR}{exp*6:.0f} (6 months of expenses).")
    L.append("\n(Rule-based advice. Add GEMINI_API_KEY in .env for AI-generated insights.)")
    return "\n".join(L)

def generate(kind, u, m):
    s = summary(u.id, m)
    prompt = (f"You are a friendly, practical personal finance advisor. {PROMPTS[kind]} "
              "Use plain text with short lines and dashes (no markdown tables, no asterisks). Be specific.\n\n" + summary_text(u, m, s))
    text = call_gemini(prompt) or rule_based(kind, s)
    db.session.add(AIReport(user_id=u.id, kind=kind, month=m, content=text))
    db.session.commit()
    return text

def latest(kind, uid, m):
    return AIReport.query.filter_by(user_id=uid, kind=kind, month=m).order_by(AIReport.id.desc()).first()

# ---------- Auth ----------
@app.route("/")
def index():
    return redirect(url_for("dashboard" if current_user.is_authenticated else "login"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name, email, pw = request.form["name"].strip(), request.form["email"].strip().lower(), request.form["password"]
        if not name or "@" not in email or len(pw) < 6:
            flash("Enter a name, valid email and a password of 6+ characters.", "error")
        elif User.query.filter_by(email=email).first():
            flash("Email already registered.", "error")
        else:
            u = User(name=name, email=email, password_hash=generate_password_hash(pw))
            db.session.add(u); db.session.commit()
            db.session.add_all(Category(user_id=u.id, name=c) for c in DEFAULT_CATS)
            db.session.commit()
            login_user(u)
            return redirect(url_for("dashboard"))
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = User.query.filter_by(email=request.form["email"].strip().lower()).first()
        if u and check_password_hash(u.password_hash, request.form["password"]):
            login_user(u)
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.", "error")
    return render_template("auth.html", mode="login")

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("login"))

@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    if request.method == "POST":
        current_user.name = request.form["name"].strip() or current_user.name
        current_user.occupation = request.form["occupation"].strip()
        current_user.goals_text = request.form["goals_text"].strip()
        db.session.commit()
        flash("Profile updated.", "ok")
    return render_template("profile.html")

# ---------- Dashboard ----------
@app.route("/dashboard")
@login_required
def dashboard():
    m = cur_month()
    s = summary(current_user.id, m)
    goals = Goal.query.filter_by(user_id=current_user.id).all()
    return render_template("dashboard.html", m=m, s=s, goals=goals, cur=CUR,
                           advice=latest("analysis", current_user.id, m))

# ---------- Income / Expenses ----------
@app.route("/income", methods=["GET", "POST"])
@login_required
def income():
    if request.method == "POST":
        a = parse_amount(request.form.get("amount"))
        if a and request.form.get("source", "").strip():
            db.session.add(Income(user_id=current_user.id, source=request.form["source"].strip(),
                                  amount=a, date=parse_date(request.form.get("date"))))
            db.session.commit(); flash("Income added.", "ok")
        else:
            flash("Enter a source and a positive amount.", "error")
        return redirect(url_for("income"))
    rows = Income.query.filter_by(user_id=current_user.id).order_by(Income.date.desc()).all()
    return render_template("records.html", kind="income", rows=rows, cats=[], cur=CUR, today=dt.date.today())

@app.route("/expenses", methods=["GET", "POST"])
@login_required
def expenses():
    cats = [c.name for c in Category.query.filter_by(user_id=current_user.id)]
    if request.method == "POST":
        a = parse_amount(request.form.get("amount"))
        if a and request.form.get("category") in cats:
            db.session.add(Expense(user_id=current_user.id, category=request.form["category"],
                                   description=request.form.get("description", "").strip(),
                                   amount=a, date=parse_date(request.form.get("date"))))
            db.session.commit(); flash("Expense added.", "ok")
        else:
            flash("Choose a category and enter a positive amount.", "error")
        return redirect(url_for("expenses"))
    rows = Expense.query.filter_by(user_id=current_user.id).order_by(Expense.date.desc()).all()
    return render_template("records.html", kind="expense", rows=rows, cats=cats, cur=CUR, today=dt.date.today())

@app.route("/delete/<kind>/<int:rid>", methods=["POST"])
@login_required
def delete(kind, rid):
    model = {"income": Income, "expense": Expense, "goal": Goal}.get(kind)
    row = model and db.session.get(model, rid)
    if row and row.user_id == current_user.id:
        db.session.delete(row); db.session.commit()
    return redirect(request.referrer or url_for("dashboard"))

# ---------- Budget & Goals ----------
@app.route("/budget", methods=["GET", "POST"])
@login_required
def budget():
    m = cur_month()
    if request.method == "POST":
        act = request.form.get("action")
        if act == "limit":
            a = parse_amount(request.form.get("limit"))
            cat = request.form.get("category")
            if a and cat:
                b = Budget.query.filter_by(user_id=current_user.id, category=cat).first()
                if b: b.limit = a
                else: db.session.add(Budget(user_id=current_user.id, category=cat, limit=a))
                db.session.commit(); flash("Budget saved.", "ok")
        elif act == "category":
            n = request.form.get("name", "").strip()
            if n and not Category.query.filter_by(user_id=current_user.id, name=n).first():
                db.session.add(Category(user_id=current_user.id, name=n)); db.session.commit()
        elif act == "generate":
            generate("budget", current_user, m); flash("AI budget plan generated.", "ok")
        return redirect(url_for("budget", month=m))
    return render_template("budget.html", m=m, s=summary(current_user.id, m), cur=CUR,
                           cats=[c.name for c in Category.query.filter_by(user_id=current_user.id)],
                           plan=latest("budget", current_user.id, m))

@app.route("/goals", methods=["GET", "POST"])
@login_required
def goals():
    if request.method == "POST":
        if request.form.get("action") == "add":
            t = parse_amount(request.form.get("target"))
            if t and request.form.get("name", "").strip():
                db.session.add(Goal(user_id=current_user.id, name=request.form["name"].strip(), target=t))
        else:
            g = db.session.get(Goal, int(request.form.get("id", 0)))
            a = parse_amount(request.form.get("amount"))
            if g and g.user_id == current_user.id and a:
                g.saved += a
        db.session.commit()
        return redirect(url_for("goals"))
    return render_template("goals.html", goals=Goal.query.filter_by(user_id=current_user.id).all(), cur=CUR)

# ---------- AI pages ----------
@app.route("/ai", methods=["GET", "POST"])
@login_required
def ai():
    m = cur_month()
    if request.method == "POST":
        kind = request.form.get("kind")
        if kind in ("analysis", "monthly"):
            generate(kind, current_user, m)
        return redirect(url_for("ai", month=m))
    return render_template("ai.html", m=m, s=summary(current_user.id, m), cur=CUR,
                           analysis=latest("analysis", current_user.id, m),
                           monthly=latest("monthly", current_user.id, m))

@app.errorhandler(404)
def nf(e):
    return render_template("auth.html", mode="login"), 404

with app.app_context():
    db.create_all()

if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    tok = os.getenv("NGROK_AUTHTOKEN")
    if tok and os.environ.get("WERKZEUG_RUN_MAIN") != "true":
        try:
            from pyngrok import ngrok
            ngrok.set_auth_token(tok)
            print("\n>>> Public URL:", ngrok.connect(port).public_url, "\n")
        except Exception as ex:
            print("Ngrok not started:", ex)
    app.run(host="0.0.0.0", port=port, debug=False)
