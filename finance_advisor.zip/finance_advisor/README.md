# Personal Finance Advisor Bot (Flask + SQLAlchemy + Gemini AI)

## Run (any device with Python 3.8+)
- **Windows:** double-click `run.bat`
- **macOS/Linux:** `./run.sh`
- Open http://127.0.0.1:5000, register, and start adding income/expenses.

## Configure (`.env`, auto-created on first run)
- `GEMINI_API_KEY` – enables Gemini AI. Without it, the app uses built-in rule-based advice (50/30/20 etc.).
- `NGROK_AUTHTOKEN` – if set, a public Ngrok URL is printed at startup.
- `DATABASE_URL` – SQLite by default; use a PostgreSQL URL (and `pip install psycopg2-binary`) if desired.

## Features
Auth (hashed passwords, sessions, protected routes) · income & expense tracking · categories · budgets with utilization ·
savings goals · dashboard charts · AI budget generation, spending analysis, monthly reports · overspending detection · emergency-fund guidance.

## Structure
`app.py` (models, routes, AI) · `templates/` (Jinja2) · `static/style.css` · `run.bat` / `run.sh`
